<?php

header('Content-Type:application/json');
header('Access-Control-Allow-Origin: *');


$con = mysqli_connect("localhost","root","","simple_form") or die ("connection_failed");
//include "config.php";

$query = "SELECT * FROM user";

$result =  mysqli_query($con,$query) or die ("SQL query failed.");


if(mysqli_num_rows($result) > 0 )
{
	$output = mysqli_fetch_all($result,MYSQLI_ASSOC);
	echo json_encode($output);
}
     
     else {
     	echo json_encode(array('message' => 'no record found.','status' => false));

     }

?>
