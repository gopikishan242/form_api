<html lang="en">
<head>
    <title>Simple Form with image upload preview using PHP and Mysql</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

   <link rel="stylesheet" href="style.css">

</head>
<body>
<div class="container">


        <form action="action.php" method="post" enctype="multipart/form-data">

                    
                            <lable >Name Item:</lable> <br>
                            <input type="text" name="name" required/><br>



                            <lable >Rwa id:</lable><br>
                            <input type="text" name="Rwa_id" required/><br>


                            <lable>User id:</lable><br>
                            <input type="text" name="User_id" required/><br>

                             

                            <lable>Service provider id: </lable><br>
                            <input type="text" name="Srvice_provider_id" required/><br>





                            <lable>Image:</lable>  <br>                          
                            <input type="file" name="image" id="profile-img" required/><br>
                                    <img src="" id="profile-img-tag" width="100px" />

                                    <script type="text/javascript">
                                        function readURL(input) {
                                            if (input.files && input.files[0]) {
                                                var reader = new FileReader();
                                                
                                                reader.onload = function (e) {
                                                    $('#profile-img-tag').attr('src', e.target.result);
                                                }
                                                reader.readAsDataURL(input.files[0]);
                                            }
                                        }
                                        $("#profile-img").change(function(){
                                            readURL(this);
                                        });
                                    </script><br>
                            <br>
                            
                            <input type="submit" name="register" value="submit" />
                                     

        </form>
   </div>     
</body>
</html>