<?php 
    if(isset($_POST['register']))
    {
        $Name_Item = $_POST['name'];
        $Rwa_id  =  $_POST['Rwa_id'];
        $User_id = $_POST['User_id'];
        $Srvice_provider_id = $_POST['Srvice_provider_id'];


        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        

        move_uploaded_file($image_tmp,"images/$image");

        $con = mysqli_connect("localhost","root","","simple_form");

        $query = "insert into user (name,Rwa_id,User_id,Srvice_provider_id,image) values ('$Name_Item','$Rwa_id','$User_id','$Srvice_provider_id','$image')";

        $result = mysqli_query($con, $query);

        if($result==1)
        {       

        echo "Inserted successfully";
        
        }
        else {       

        echo "Insertion Failed";

             }
    }
?>